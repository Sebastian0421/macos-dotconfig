# nvim-doc-tools
Python scripts for Neovim documentation generation

I don't expect anyone but me to use this, but you're welcome to I guess.
