---
name: Bug report (missing treesitter symbols)
about: Missing symbols with the treesitter backend
title: ''
labels: ''
assignees: stevearc

---

**Language**: [your language]
**AerialInfo**: [output of :AerialInfo]

The minimal amount of code that demonstrates the missing symbol:
```
[minimal code here]
```

**Expected symbol**: [Function/Class/Enum]
