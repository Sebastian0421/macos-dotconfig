<?php
function my_function () { }

$var_function = function () { };

class MyClass {
    public function myMethod() { }
}
interface InterfaceOne {
    public function doSomething();
}

trait MyTrait {
    public function myTraitMethod() { }
}
