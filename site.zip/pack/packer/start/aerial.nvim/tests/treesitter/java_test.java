interface Iface_1 {
  void meth_1();
}

class Cl_1 {
  void meth_2() { }
  private int field_1;
  public Object field_2;
}

enum En_1 { }
