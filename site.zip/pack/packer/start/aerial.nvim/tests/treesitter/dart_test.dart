class Class_1 {
  Class_1();

  void meth_1() { }

  int get prop {
    return 0;
  }

  void set prop(int newval) { }
}

void function_1() { }

enum Enum_1 { 
   none, 
}
