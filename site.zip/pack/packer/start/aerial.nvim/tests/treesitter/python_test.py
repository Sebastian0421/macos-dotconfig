def fn_1():
    pass


class cl_1:
    def meth_1(self):
        pass
