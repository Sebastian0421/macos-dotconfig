local Whichkey = {
		WhichKey = {fg = C.purple, },
		WhichKeySeperator = {fg = C.green, },
		WhichKeyGroup = {fg = C.blue, },
		WhichKeyDesc = {fg = C.cyan, },
		WhichKeyFloat = {bg = C.alt_bg, },
}

return Whichkey