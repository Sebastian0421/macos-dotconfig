local Packer = {
		packerString = {fg = C.ui_orange, },
		packerHash = {fg = C.ui4_blue, },
		packerOutput = {fg = C.ui_purple, },
		packerRelDate = {fg = C.gray, },
		packerSuccess = {fg = C.success_green, },
		packerStatusSuccess = {fg = C.ui4_blue, },
}

return Packer