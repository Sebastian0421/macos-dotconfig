local Crates = {
		CratesNvimLoading = {fg = C.hint_blue, },
		CratesNvimVersion = {fg = C.hint_blue, },
}

return Crates