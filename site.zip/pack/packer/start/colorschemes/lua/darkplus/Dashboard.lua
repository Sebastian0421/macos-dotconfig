local Dashboard = {
		DashboardHeader = {fg = C.blue, },
		DashboardCenter = {fg = C.purple, },
		DashboardFooter = {fg = C.cyan, },
}

return Dashboard