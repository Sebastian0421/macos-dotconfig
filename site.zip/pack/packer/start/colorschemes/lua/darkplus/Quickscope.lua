local Quickscope = {
		QuickScopePrimary = {fg = C.purple_test, style = "underline", },
		QuickScopeSecondary = {fg = C.cyan_test, style = "underline", },
}

return Quickscope