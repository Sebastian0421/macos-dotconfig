local SymbolOutline = {
		SymbolsOutlineConnector = {fg = C.gray, },
		FocusedSymbol = {bg = "#36383F", },
}

return SymbolOutline