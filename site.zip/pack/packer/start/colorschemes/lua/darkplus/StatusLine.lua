local StatusLine = {
		StatusLine = {fg = C.alt_bg, bg = C.gray, },
		StatusLineNC = {fg = C.alt_bg, bg = C.gray, },
		StatusLineSeparator = {fg = C.alt_bg, },
		StatusLineTerm = {fg = C.alt_bg, },
		StatusLineTermNC = {fg = C.alt_bg, },
}

return StatusLine