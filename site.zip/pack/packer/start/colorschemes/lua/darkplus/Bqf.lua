local Bqf = {
		BqfPreviewBorder = {fg = C.fg, },
		BqfPreviewRange = {bg = C.ui2_blue, },
}

return Bqf