local Lir = {
		LirFloatNormal = {fg = C.light_gray, bg = C.alt_bg, },
		LirDir = {fg = C.blue, },
		LirSymLink = {fg = C.cyan, },
		LirEmptyDirText = {fg = C.blue, },
}

return Lir