local IndentBlankline = {
		IndentBlanklineContextChar = {fg = C.context, },
		IndentBlanklineContextStart = {style = "underline", },
		IndentBlanklineChar = {fg = C.dark_gray, },
		IndentBlanklineSpaceChar = {fg = C.cyan_test, },
		IndentBlanklineSpaceCharBlankline = {fg = C.info_yellow, },
}

return IndentBlankline