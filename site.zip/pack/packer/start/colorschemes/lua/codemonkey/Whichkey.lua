local Whichkey = {
		WhichKey = {fg = C.purple, },
		WhichKeySeperator = {fg = C.green, },
		WhichKeyGroup = {fg = C.blue, },
		WhichKeyDesc = {fg = C.light_blue, },
		WhichKeyFloat = {bg = C.dark, },
}

return Whichkey