local Bookmarks = {
		BookmarkSign = {fg = C.sign_change, },
		BookmarkAnnotationSign = {fg = C.yellow, },
		BookmarkLine = {fg = C.ui2_blue, },
		BookmarkAnnotationLine = {fg = C.ui2_blue, },
}

return Bookmarks