local StatusLine = {
		StatusLine = {fg = C.line, bg = C.gray, },
		StatusLineNC = {fg = C.line, bg = C.gray, },
		StatusLineSeparator = {fg = C.line, },
		StatusLineTerm = {fg = C.line, },
		StatusLineTermNC = {fg = C.line, },
}

return StatusLine