local Hop = {
		HopNextKey = {fg = "#4ae0ff", },
		HopNextKey1 = {fg = "#d44EeD", },
		HopNextKey2 = {fg = "#b42EcD", },
		HopUnmatched = {fg = C.gray, },
		HopPreview = {fg = "#c7bA7D", },
}

return Hop