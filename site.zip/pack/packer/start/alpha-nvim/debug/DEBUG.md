run with one of these (in order of preference)
- `nvim --clean -u *.lua`
- `nvim --noplugin -u *.lua`
- `nvim -u *.lua`
