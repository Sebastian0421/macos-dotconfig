local M = {}

function M.get()
	return {
		FocusedSymbol = { fg = cp.yellow, bg = cp.base },
	}
end

return M
