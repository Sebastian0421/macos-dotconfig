local M = {}

function M.get()
	return {
		Beacon = { bg = cp.blue },
	}
end

return M
