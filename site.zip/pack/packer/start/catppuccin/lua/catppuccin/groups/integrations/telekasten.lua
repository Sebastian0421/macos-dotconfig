local M = {}

function M.get()
	return {
		tkLink = { fg = cp.blue },
		tkBrackets = { fg = cp.pink },
		tkTag = { fg = cp.sky },
	}
end

return M
