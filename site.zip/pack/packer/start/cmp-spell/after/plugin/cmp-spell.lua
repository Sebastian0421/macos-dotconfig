require('cmp').register_source('spell', require('cmp-spell').new())
